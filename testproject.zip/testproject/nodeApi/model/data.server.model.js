(function () {


    'use strict';

    var mongoose = require('mongoose'),
        regex = require('regex'),
        Schema = mongoose.Schema;

    var dataSchema = new Schema({
        name: {
            type: String,
            trim: true
        },
        email: {
            type: String,
            trim: true
        },
        city : {
            type: String,
            trim: true
        },
        state: {
            type: String,
            trim: true
        },
        updatedOn: {
            type: Date
        },
        addedOn: {
            type: Date,
            default: Date.now
        },
        deleted: {
            type: Boolean,
            default: false
        },
        deletedBy: {
            type: String,
            trim: true
        },
        deletedOn: {
            type: Date
        }
    });

    module.exports = mongoose.model('data', dataSchema, 'data');
    var dataCreateSchema = mongoose.model('data', dataSchema, 'data');

    module.exports.createdata = function (req, res) {
        var dataSchema = dataCreateSchema(req.body)
        return dataSchema.save(dataSchema);
    }

    module.exports.findByFilter = function (req, res) {
    
        var limit = req.body.limit;
        var page = req.body.page

        var skipData = (page-1)*limit;
        
        var queryObject = {};

        if (req.body) {
            queryObject['$and'] = [];
            queryObject['$and'].push({
                "deleted":false
            });
        }

        if (req.body.name) {
            queryObject['$and'].push({
                "name":req.body.name
            });
        }

        if (req.body.state) {
            queryObject['$and'].push({
                "state":req.body.state
            });
        }

        if (req.body.email) {
            queryObject['$and'].push({
                "email":req.body.email
            });
        }

        if (req.body.city) {
            queryObject['$and'].push({
                "city":req.body.city
            });
        }


        return dataCreateSchema.aggregate([
            {
                $match: queryObject
            },
            { 
                $skip : skipData 
            },
            {
                $limit:limit
            }
        ]).exec()
    }

    module.exports.deleteById = function (req, res) {
        return dataCreateSchema.findOneAndUpdate({_id:req.body._id}, {deleted: true}).exec();
    }

    module.exports.updateById = function (req, res) {
        return dataCreateSchema.findOneAndUpdate({_id:req.body._id}, req.body).exec();
    }

    module.exports.getAlldata = function (req,res) {
        return dataSchema.find({}).sort({updatedOn: -1}).exec();
    };
})();