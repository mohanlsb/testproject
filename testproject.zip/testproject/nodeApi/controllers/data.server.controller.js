var dataController = (function () {

    'use strict';

    var data = require('../model/data.server.model');
    function dataModule() { }

    var _p = dataModule.prototype;


    _p.findallData =function (req, res) {
        data.getAlldata(req,res).then(resData => {
            res.status(200).json({
                status: true,
                message: "All Data",
                data: resData
            });
        })
        .catch(err => {
            res.status(500).json({
              error: err,
              status: false
            })
          })
    }

    _p.updateById = function (req, res) {
        data.updateById(req,res).then(resData => {
            res.status(200).json({
                status: true,
                message: "data updated Successfully",
                data:resData
            });
        })
        .catch(err => {
            res.status(500).json({
              error: err,
              status: false
            })
          })
    }

    _p.deleteById = function (req, res) {
        data.deleteById(req,res).then(resData => {
            res.status(200).json({
                status: true,
                message: "data deleted Successfully"
            });
        })
        .catch(err => {
            res.status(500).json({
              error: err,
              status: false
            })
          })
    }

    _p.findByFilter = function (req, res) {
        data.findByFilter(req,res).then(resData => {
            res.status(200).json({
                status: true,
                message: "data founded Successfully",
                data: resData
            });
        })
        .catch(err => {
            res.status(500).json({
              error: err,
              status: false
            })
          })
    }

    _p.createdata = function (req, res) {
        data.createdata(req,res).then(resData => {
            res.status(200).json({
                status: true,
                message: "data Created Successfully",
                data: resData
            });
        })
        .catch(err => {
            res.status(500).json({
              error: err,
              status: false
            })
          })
    };

    return {
        createdata:_p.createdata,
        findallData:_p.findallData,
        findByFilter:_p.findByFilter,
        deleteById:_p.deleteById,
        updateById:_p.updateById
    };
})();

module.exports = dataController;