var DataRouters = (function () {

    'use strict';

    var express = require('express'),
        DataController = require('../controllers/data.server.controller'),
        DataRouter = express.Router();

    DataRouter.route('/createdata').post(DataController.createdata);
    DataRouter.route('/findallData').post(DataController.findallData);
    DataRouter.route('/findByFilter').post(DataController.findByFilter);
    DataRouter.route('/deleteById').post(DataController.deleteById);
    DataRouter.route('/updateById').post(DataController.updateById);

    return DataRouter;

})();

module.exports = DataRouters;