import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListRoutingModule } from './list-display-routing.module';
import { ListDisplayComponent } from './list-display.component';
import { ListDisplayService } from './list-display.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    ListDisplayComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ListRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers:[
    ListDisplayService
  ]
})
export class ListDisplayModule { }
