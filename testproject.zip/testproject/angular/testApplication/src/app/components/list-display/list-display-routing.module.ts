import {NgModule} from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListDisplayComponent } from './list-display.component';

const routes: Routes = [
  {
    path:'',
    component: ListDisplayComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ListRoutingModule { }