import { Component, OnInit } from '@angular/core';
import { ListDisplayService } from './list-display.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-list-display',
  templateUrl: './list-display.component.html',
  styleUrls: ['./list-display.component.scss']
})
export class ListDisplayComponent implements OnInit {

  displayData: any = [];
  searchByName:FormGroup;
  limit:number = 10;
  page:number = 1;

  constructor(private listService:ListDisplayService) {
    this.searchByName = new FormGroup({
      name: new FormControl()
    });
   }

  ngOnInit() {
    let objData = {
      limit : this.limit,
      page : this.page
    }
    this.listService.getAllData(objData).subscribe(resData => {
      console.log("responce Data", resData);
      this.displayData = resData.data;
    })
  }

  submitForm () {
    let objData = {
      limit : this.limit,
      page : this.page,
      name: this.searchByName.value.name
    }
    this.listService.getAllData(objData).subscribe(resData => {
      console.log("responce Data", resData);
      debugger
      this.displayData = resData.data;
    })
  }

  DeleteData (dataId) {
    console.log("dataId", dataId)
    this.listService.findOneAndDelete({_id:dataId}).subscribe(resData => {
      console.log("hello Data")
    })
  }

  changePage (pageNo) {
    this.page = pageNo;
    this.submitForm();
  }

}
