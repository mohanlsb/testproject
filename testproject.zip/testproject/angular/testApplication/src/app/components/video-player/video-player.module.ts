import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VideoRoutingModule } from './video-player-routing.module';
import { VideoPlayerComponent } from './video-player.component';
import { HttpClientModule } from '@angular/common/http';
import { EmbedVideoService } from 'ngx-embed-video';



@NgModule({
  declarations: [VideoPlayerComponent],
  imports: [
    CommonModule,
    VideoRoutingModule,
    HttpClientModule
  ],
  providers:[
    EmbedVideoService
  ]
})
export class VideoPlayerModule { }
